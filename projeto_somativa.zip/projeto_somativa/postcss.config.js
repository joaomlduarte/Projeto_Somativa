export default {
  plugins: {
    '@tailwindcss/postcss': {},  // <- plugin novo
    autoprefixer: {},
  },
}
