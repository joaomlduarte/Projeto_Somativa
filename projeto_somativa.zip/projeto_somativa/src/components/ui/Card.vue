<template>
  <div class="p-4 rounded-2xl bg-white shadow-sm border border-gray-100">
    <slot />
  </div>
</template>

