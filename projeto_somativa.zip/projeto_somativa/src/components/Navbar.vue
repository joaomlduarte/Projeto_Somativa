<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'

const router = useRouter()
const auth = useAuthStore()

function toggleSidebar() {
  // Emite pro App.vue abrir/fechar o drawer no mobile
  emit('toggle-sidebar')
}
const emit = defineEmits(['toggle-sidebar'])

function logout() {
  auth.logout()
  router.push({ name: 'login' })
}
</script>

<template>
  <header class="sticky top-0 z-40 bg-white border-b shadow-sm">
    <div class="flex items-center justify-between px-4 h-14">
      <!-- Botão menu (mobile) -->
      <button
        class="lg:hidden p-2 rounded hover:bg-gray-100"
        @click="toggleSidebar"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>

      <!-- Logo / Título -->
      <div class="font-semibold text-gray-700">
        SMPM - Sistema de Manutenção
      </div>

      <!-- Avatar + Logout -->
      <div class="flex items-center gap-3">
        <!-- Avatar do usuário -->
        <img v-if="auth.user" src="/avatar-admin.png" alt="Admin" class="w-8 h-8 rounded-full"/>

        <!-- Botão de logout -->
        <button
          @click="logout"
          class="text-sm text-red-600 hover:text-red-700 px-2 py-1 rounded hover:bg-red-50"
        >
          Sair
        </button>
      </div>
    </div>
  </header>
</template>
